				<li class="purple">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-bell icon-animated-bell"></i>
								<span class="badge badge-important">+</span>
							</a>

							<ul class="dropdown-menu-right dropdown-navbar navbar-pink dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-exclamation-triangle"></i>
									View Company Notifications
								</li>
									<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">



<li><a href="allnotifications.php"><div class="clearfix"><span class="pull-left"><i class="btn btn-xs no-hover btn-info fa fa-bell"></i>Notify here</span><span class="pull-right badge badge-info">Date</span></div></a></li>




									

									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="allnotifications.php">
										See all notifications
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>