<h2><?= esc($news['title']); ?></h2>
<?= esc($news['body']); ?>